/*
 * =====================================================================
 *  usuarios.h  -  REDES Práctica 2: Dominio Territorial
 * ---------------------------------------------------------------------
 *  Gestión de los usuarios registrados. Se guardan en un fichero de
 *  texto (usuarios.txt) con una línea por usuario:
 *
 *      usuario password
 *
 *  Así los usuarios no se pierden al apagar el servidor.
 *
 *  Este módulo solo sabe de ese fichero. No sabe nada de sockets ni de
 *  qué clientes están conectados: eso es cosa de servidor.c.
 * =====================================================================
 */

#ifndef USUARIOS_H
#define USUARIOS_H

#define FICHERO_USUARIOS  "usuarios.txt"
#define MAX_NOMBRE        50    /* Usuario y password: 49 caracteres como máximo
                                   (el último hueco es para el '\0')            */

/* Lo que devuelve registrarUsuario() */
typedef enum {
    REGISTRO_OK,                /* Usuario guardado en el fichero            */
    REGISTRO_YA_EXISTE,         /* Ya hay un usuario con ese nombre          */
    REGISTRO_DEMASIADO_LARGO,   /* Usuario o password de 50 caracteres o más */
    REGISTRO_ERROR_FICHERO      /* No se ha podido escribir en el fichero    */
} ResultadoRegistro;

/* 1 si hay un usuario registrado con ese nombre, 0 si no */
int usuarioExiste(const char *nombre);

/* 1 si el usuario existe y esa es su password, 0 en caso contrario */
int passwordCorrecta(const char *nombre, const char *password);

/* Añade un usuario nuevo, controlando que el nombre no esté repetido */
ResultadoRegistro registrarUsuario(const char *nombre, const char *password);

#endif