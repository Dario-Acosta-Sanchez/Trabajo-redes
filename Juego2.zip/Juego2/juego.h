/*
 * =====================================================================
 *  juego.h  -  REDES Práctica 2: Dominio Territorial
 * ---------------------------------------------------------------------
 *  Lógica del juego: tablero, reglas y recuento final.
 *
 *  Este módulo NO sabe nada de sockets ni de clientes. Solo trabaja con
 *  un tablero y con los jugadores 1 y 2. El servidor lo usa así:
 *      mensaje del cliente -> servidor.c -> función de juego.c
 *                          <- resultado  <-
 *  y es el servidor quien convierte el resultado en "+Ok." o "-Err.".
 * =====================================================================
 */

#ifndef JUEGO_H
#define JUEGO_H

/* ---------------------------------------------------------------------
 *  Constantes del juego
 * --------------------------------------------------------------------- */
#define TAM                 5     /* Tablero de 5 x 5: filas A-E, columnas 1-5  */
#define UNIDADES_INICIALES  30
#define MAX_TURNOS          50    /* El enunciado no lo fija: decisión nuestra   */
#define MIN_UNIDADES_ORIGEN 0     /* Unidades que deben quedar en el origen:
                                     0 = se pueden mover todas (enunciado literal)
                                     1 = obliga a dejar siempre una de guarnición */
#define NEUTRAL             0     /* Propietario de un territorio sin conquistar */

/* Línea con los números de columna, alineada con filaTablero() */
#define CABECERA_TABLERO    "    1      2      3      4      5\n"

/* ---------------------------------------------------------------------
 *  Tipos de datos
 * --------------------------------------------------------------------- */
typedef struct {
    int propietario;            /* NEUTRAL (0), 1 = J1, 2 = J2 */
    int unidades;
} Territorio;

typedef struct {
    Territorio tablero[TAM][TAM];   /* tablero[fila][columna]            */
    int turno;                      /* 1 o 2: jugador al que le toca     */
    int turnosJugados;              /* Acciones válidas realizadas       */
} Juego;

/* Las tres acciones que mueven unidades */
typedef enum { CONQUISTAR, ATACAR, REFORZAR } Accion;

/*
 * Lo que devuelven realizarAccion() y pasarTurno().
 * Los tres primeros valores son acciones válidas; a partir de
 * ERR_NO_ES_TU_TURNO son errores y el tablero NO se ha modificado.
 */
typedef enum {
    ACCION_OK,                  /* Conquista, refuerzo o pasar: hecho         */
    ATAQUE_GANADO,              /* El atacante conquista el territorio        */
    ATAQUE_PERDIDO,             /* El atacante pierde las unidades usadas     */

    ERR_NO_ES_TU_TURNO,
    ERR_ORIGEN_NO_EXISTE,
    ERR_DESTINO_NO_EXISTE,
    ERR_ORIGEN_NO_ES_TUYO,
    ERR_DESTINO_NO_NEUTRAL,     /* CONQUISTAR un territorio ya ocupado        */
    ERR_ATACAR_PROPIO,          /* ATACAR uno de tus propios territorios      */
    ERR_DESTINO_NO_ES_RIVAL,    /* ATACAR un territorio neutral               */
    ERR_DESTINO_NO_ES_TUYO,     /* REFORZAR un territorio que no es tuyo      */
    ERR_NO_ADYACENTES,
    ERR_UNIDADES_NO_VALIDAS,    /* Cero o negativas                           */
    ERR_UNIDADES_INSUFICIENTES
} Resultado;

/* ---------------------------------------------------------------------
 *  Funciones
 * --------------------------------------------------------------------- */

/* Prepara una partida nueva. Devuelve en inicioJ1 / inicioJ2 (char[3])
   el nombre del territorio inicial de cada jugador, p. ej. "B2".
   Usa rand(): hay que llamar a srand() una vez al arrancar el programa. */
void iniciarJuego(Juego *j, char *inicioJ1, char *inicioJ2);

/* "B3" -> fila 1, columna 2. Devuelve 1 si existe, 0 si no. */
int  parsearTerritorio(const char *s, int *fila, int *col);

/* fila 1, columna 2 -> "B3" (nombre debe tener sitio para 3 caracteres) */
void nombreTerritorio(int fila, int col, char *nombre);

/* 1 si las dos casillas se tocan por arriba, abajo, izquierda o derecha */
int  adyacentes(int f1, int c1, int f2, int c2);

/* Comprueba todas las reglas y, si la acción es válida, la aplica y
   pasa el turno al otro jugador. */
Resultado realizarAccion(Juego *j, int jugador, Accion accion,
                         const char *origen, const char *destino, int unidades);

/* El jugador termina su turno sin hacer nada */
Resultado pasarTurno(Juego *j, int jugador);

/* 1 si el resultado es uno de los ERR_... */
int  esError(Resultado r);

/* Cuenta los territorios y las unidades de un jugador */
void contarJugador(const Juego *j, int jugador, int *territorios, int *unidades);

/* 1 si la partida ha terminado */
int  juegoTerminado(const Juego *j);

/* 1 o 2 según quién gane; 0 si hay empate total */
int  ganadorJuego(const Juego *j);

/* Escribe en linea la fila indicada del tablero tal y como la ve ese
   jugador: de sus territorios ve las unidades, de los del rival no. */
void filaTablero(const Juego *j, int jugador, int fila, char *linea, int tam);

#endif