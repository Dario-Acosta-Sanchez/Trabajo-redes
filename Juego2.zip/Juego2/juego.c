/*
 * =====================================================================
 *  juego.c  -  REDES Práctica 2: Dominio Territorial
 * ---------------------------------------------------------------------
 *  Implementación de la lógica del juego (ver juego.h).
 *  Aquí no hay ni un solo socket: solo tablero y reglas.
 * =====================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "juego.h"


/* Función interna (static = solo se ve dentro de este fichero) */
static void siguienteTurno(Juego *j);


/* =====================================================================
 *  INICIO DE LA PARTIDA
 * ===================================================================== */

void iniciarJuego(Juego *j, char *inicioJ1, char *inicioJ2)
{
    int f, c, pos1, pos2;

    /* Todo el tablero neutral y sin unidades */
    for (f = 0; f < TAM; f++)
        for (c = 0; c < TAM; c++) {
            j->tablero[f][c].propietario = NEUTRAL;
            j->tablero[f][c].unidades    = 0;
        }

    /* Dos casillas aleatorias DISTINTAS. Numeramos las 25 casillas de
       0 a 24: la casilla n está en la fila n / 5 y la columna n % 5. */
    pos1 = rand() % (TAM * TAM);
    do {
        pos2 = rand() % (TAM * TAM);
    } while (pos2 == pos1);

    j->tablero[pos1 / TAM][pos1 % TAM].propietario = 1;
    j->tablero[pos1 / TAM][pos1 % TAM].unidades    = UNIDADES_INICIALES;
    j->tablero[pos2 / TAM][pos2 % TAM].propietario = 2;
    j->tablero[pos2 / TAM][pos2 % TAM].unidades    = UNIDADES_INICIALES;

    nombreTerritorio(pos1 / TAM, pos1 % TAM, inicioJ1);
    nombreTerritorio(pos2 / TAM, pos2 % TAM, inicioJ2);

    j->turno         = 1;       /* Empieza J1 */
    j->turnosJugados = 0;
}


/* =====================================================================
 *  TERRITORIOS
 * ===================================================================== */

/* "B3" -> fila 1, columna 2. Devuelve 0 si el territorio no existe */
int parsearTerritorio(const char *s, int *fila, int *col)
{
    char letra;

    if (strlen(s) != 2)                          /* Una letra y un número */
        return 0;

    letra = toupper((unsigned char) s[0]);       /* Aceptamos "b3" y "B3" */
    if (letra < 'A' || letra >= 'A' + TAM)
        return 0;
    if (s[1] < '1' || s[1] >= '1' + TAM)
        return 0;

    *fila = letra - 'A';                         /* 'B' - 'A' = 1 */
    *col  = s[1] - '1';                          /* '3' - '1' = 2 */
    return 1;
}

/* fila 1, columna 2 -> "B3" */
void nombreTerritorio(int fila, int col, char *nombre)
{
    nombre[0] = 'A' + fila;
    nombre[1] = '1' + col;
    nombre[2] = '\0';
}

/*
 * Dos casillas son adyacentes si están a distancia 1 moviéndose solo en
 * horizontal o vertical. En diagonal la suma da 2, y si origen y destino
 * son la misma casilla da 0: en ambos casos NO son adyacentes.
 */
int adyacentes(int f1, int c1, int f2, int c2)
{
    return abs(f1 - f2) + abs(c1 - c2) == 1;
}


/* =====================================================================
 *  ACCIONES
 * ===================================================================== */

/* Cuenta el turno jugado y se lo pasa al otro: 3 - 1 = 2 y 3 - 2 = 1 */
static void siguienteTurno(Juego *j)
{
    j->turnosJugados++;
    j->turno = 3 - j->turno;
}

int esError(Resultado r)
{
    return r >= ERR_NO_ES_TU_TURNO;
}

/*
 * CONQUISTAR, ATACAR y REFORZAR comparten casi todas las comprobaciones;
 * solo cambia la condición que debe cumplir el territorio de destino.
 * Si algo falla se devuelve el error y el tablero queda intacto.
 */
Resultado realizarAccion(Juego *j, int jugador, Accion accion,
                         const char *origen, const char *destino, int unidades)
{
    Territorio *orig, *dest;
    int fo, co, fd, cd;
    int rival = 3 - jugador;
    Resultado resultado = ACCION_OK;

    /* 1. Es el turno del jugador */
    if (j->turno != jugador)
        return ERR_NO_ES_TU_TURNO;

    /* 2. Los dos territorios existen */
    if (!parsearTerritorio(origen, &fo, &co))
        return ERR_ORIGEN_NO_EXISTE;
    if (!parsearTerritorio(destino, &fd, &cd))
        return ERR_DESTINO_NO_EXISTE;

    orig = &j->tablero[fo][co];
    dest = &j->tablero[fd][cd];

    /* 3. El origen pertenece al jugador */
    if (orig->propietario != jugador)
        return ERR_ORIGEN_NO_ES_TUYO;

    /* 4. Condición sobre el destino, distinta en cada acción */
    if (accion == CONQUISTAR && dest->propietario != NEUTRAL)
        return ERR_DESTINO_NO_NEUTRAL;
    if (accion == ATACAR && dest->propietario == jugador)
        return ERR_ATACAR_PROPIO;
    if (accion == ATACAR && dest->propietario != rival)
        return ERR_DESTINO_NO_ES_RIVAL;
    if (accion == REFORZAR && dest->propietario != jugador)
        return ERR_DESTINO_NO_ES_TUYO;

    /* 5. Son adyacentes */
    if (!adyacentes(fo, co, fd, cd))
        return ERR_NO_ADYACENTES;

    /* 6. Hay unidades suficientes en el origen */
    if (unidades <= 0)
        return ERR_UNIDADES_NO_VALIDAS;
    if (unidades > orig->unidades - MIN_UNIDADES_ORIGEN)
        return ERR_UNIDADES_INSUFICIENTES;

    /* ---- Todo correcto: se aplica la acción ---- */
    orig->unidades -= unidades;          /* Las unidades siempre salen del origen */

    switch (accion) {
    case CONQUISTAR:
        dest->propietario = jugador;
        dest->unidades    = unidades;
        break;

    case ATACAR:
        if (unidades > dest->unidades) {
            /* Éxito: las unidades del defensor se pierden y las
               atacantes ocupan el territorio */
            dest->propietario = jugador;
            dest->unidades    = unidades;
            resultado = ATAQUE_GANADO;
        }
        else {
            /* Fracaso (también si empatan): el atacante pierde las
               unidades usadas y el defensor se queda como estaba */
            resultado = ATAQUE_PERDIDO;
        }
        break;

    case REFORZAR:
        dest->unidades += unidades;
        break;
    }

    siguienteTurno(j);
    return resultado;
}

Resultado pasarTurno(Juego *j, int jugador)
{
    if (j->turno != jugador)
        return ERR_NO_ES_TU_TURNO;

    siguienteTurno(j);
    return ACCION_OK;
}


/* =====================================================================
 *  FIN DE LA PARTIDA
 * ===================================================================== */

void contarJugador(const Juego *j, int jugador, int *territorios, int *unidades)
{
    int f, c;

    *territorios = 0;
    *unidades    = 0;

    for (f = 0; f < TAM; f++)
        for (c = 0; c < TAM; c++)
            if (j->tablero[f][c].propietario == jugador) {
                (*territorios)++;
                *unidades += j->tablero[f][c].unidades;
            }
}

/*
 * La partida termina si:
 *  - se alcanza el máximo de turnos,
 *  - un jugador controla los 25 territorios,
 *  - o un jugador se queda sin territorios (ya no podría hacer nada).
 */
int juegoTerminado(const Juego *j)
{
    int t1, u1, t2, u2;

    contarJugador(j, 1, &t1, &u1);
    contarJugador(j, 2, &t2, &u2);

    return j->turnosJugados >= MAX_TURNOS ||
           t1 == TAM * TAM || t2 == TAM * TAM ||
           t1 == 0 || t2 == 0;
}

/* Gana quien tenga más territorios; si empatan, quien tenga más unidades */
int ganadorJuego(const Juego *j)
{
    int t1, u1, t2, u2;

    contarJugador(j, 1, &t1, &u1);
    contarJugador(j, 2, &t2, &u2);

    if (t1 > t2) return 1;
    if (t2 > t1) return 2;
    if (u1 > u2) return 1;
    if (u2 > u1) return 2;
    return 0;                            /* Empate total */
}


/* =====================================================================
 *  ESTADO DEL TABLERO
 * ===================================================================== */

/*
 * Construye una fila del tablero vista por "jugador":
 *   .        territorio neutral
 *   J1(25)   territorio propio: se ven las unidades
 *   J2       territorio del rival: NO se ven las unidades
 */
void filaTablero(const Juego *j, int jugador, int fila, char *linea, int tam)
{
    const Territorio *t;
    char celda[16];
    int col, n;

    snprintf(linea, tam, "%c   ", 'A' + fila);

    for (col = 0; col < TAM; col++) {
        t = &j->tablero[fila][col];

        if (t->propietario == NEUTRAL)
            strcpy(celda, ".");
        else if (t->propietario == jugador)
            snprintf(celda, sizeof(celda), "J%d(%d)", t->propietario, t->unidades);
        else
            snprintf(celda, sizeof(celda), "J%d", t->propietario);

        /* %-7s = alineado a la izquierda en 7 caracteres (columnas rectas) */
        n = strlen(linea);
        snprintf(linea + n, tam - n, "%-7s", celda);
    }

    /* Quitamos los espacios sobrantes del final y cerramos la línea */
    n = strlen(linea);
    while (n > 0 && linea[n - 1] == ' ')
        n--;
    snprintf(linea + n, tam - n, "\n");
}