/*
 * =====================================================================
 *  usuarios.c  -  REDES Práctica 2: Dominio Territorial
 * ---------------------------------------------------------------------
 *  Implementación de la gestión de usuarios (ver usuarios.h).
 *  Cada consulta abre el fichero, lo recorre y lo cierra: así siempre
 *  se trabaja con lo que hay guardado en disco en ese momento.
 * =====================================================================
 */

#include <stdio.h>
#include <string.h>
#include "usuarios.h"


/* Función interna (static = solo se ve dentro de este fichero) */
static int buscarUsuario(const char *nombre, char *password);


/*
 * Recorre el fichero buscando el usuario "nombre".
 * Si lo encuentra devuelve 1 y deja su password en "password"
 * (un array de MAX_NOMBRE caracteres). Si no, devuelve 0.
 */
static int buscarUsuario(const char *nombre, char *password)
{
    FILE *f = fopen(FICHERO_USUARIOS, "r");
    char u[MAX_NOMBRE], p[MAX_NOMBRE];

    if (f == NULL)              /* Si el fichero aún no existe, no hay usuarios */
        return 0;

    /* Cada línea son dos palabras: usuario y password. El 49 limita lo
       que lee fscanf a MAX_NOMBRE - 1 caracteres para no salirse del array */
    while (fscanf(f, "%49s %49s", u, p) == 2) {
        if (strcmp(u, nombre) == 0) {
            strcpy(password, p);
            fclose(f);
            return 1;
        }
    }

    fclose(f);
    return 0;
}

int usuarioExiste(const char *nombre)
{
    char password[MAX_NOMBRE];

    return buscarUsuario(nombre, password);
}

int passwordCorrecta(const char *nombre, const char *password)
{
    char guardada[MAX_NOMBRE];

    if (!buscarUsuario(nombre, guardada))
        return 0;

    return strcmp(guardada, password) == 0;
}

ResultadoRegistro registrarUsuario(const char *nombre, const char *password)
{
    FILE *f;

    if (strlen(nombre) >= MAX_NOMBRE || strlen(password) >= MAX_NOMBRE)
        return REGISTRO_DEMASIADO_LARGO;

    if (usuarioExiste(nombre))          /* Control de colisiones de nombres */
        return REGISTRO_YA_EXISTE;

    f = fopen(FICHERO_USUARIOS, "a");   /* "a" = añadir al final (lo crea si no existe) */
    if (f == NULL)
        return REGISTRO_ERROR_FICHERO;

    fprintf(f, "%s %s\n", nombre, password);
    fclose(f);
    return REGISTRO_OK;
}