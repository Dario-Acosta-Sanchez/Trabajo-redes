/*
 * =====================================================================
 *  cliente.c  -  REDES Práctica 2: Dominio Territorial
 * ---------------------------------------------------------------------
 *  Cliente TCP de consola. No conoce las reglas del juego: solo envía al
 *  servidor lo que escribe el jugador y muestra lo que el servidor
 *  responde. Usa select() para atender a la vez el teclado y el socket,
 *  porque el servidor puede escribirnos en cualquier momento (empieza la
 *  partida, el rival ha jugado, el rival se ha ido...).
 *
 *  Compilar:  gcc -Wall cliente.c -o cliente
 *  Ejecutar:  ./cliente                (servidor en esta misma máquina)
 *             ./cliente 192.168.1.20   (IP o nombre del servidor)
 * =====================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>


#define PUERTO     2026
#define MSG_SIZE   250    /* Tamaño fijo de cada mensaje en el socket (igual que el servidor) */
#define MAX_TEXTO  200    /* Longitud máxima del texto de un mensaje (enunciado)              */


int  enviarMensaje(int sd, const char *texto);
int  recibirMensaje(int sd, char *buffer);
void mostrarAyuda(void);


int main(int argc, char *argv[])
{
    /*----------------------------------------------------
        Descriptor del socket y buffer de datos
    -----------------------------------------------------*/
    int sd;
    struct sockaddr_in sockname;
    struct hostent *host;
    char buffer[MSG_SIZE];
    fd_set readfds, auxfds;
    int salida, largo, ch;
    int fin = 0;
    const char *servidor = (argc > 1) ? argv[1] : "127.0.0.1";

    /* Sin buffer en el teclado: así fgets() no se guarda líneas "por
       adelantado" que select() no podría ver */
    setvbuf(stdin, NULL, _IONBF, 0);

    /* --------------------------------------------------
        1. Se abre el socket (SOCK_STREAM = TCP)
    ---------------------------------------------------*/
    sd = socket(AF_INET, SOCK_STREAM, 0);
    if (sd == -1) {
        perror("No se puede abrir el socket cliente");
        exit(1);
    }

    /* ------------------------------------------------------------------
        2. Se rellena la estructura con la IP del servidor y el puerto.
           gethostbyname() acepta tanto una IP ("127.0.0.1") como un
           nombre ("localhost") y nos devuelve la dirección en binario.
    -------------------------------------------------------------------*/
    host = gethostbyname(servidor);
    if (host == NULL) {
        fprintf(stderr, "No se encuentra el servidor %s\n", servidor);
        exit(1);
    }

    bzero(&sockname, sizeof(sockname));
    sockname.sin_family = AF_INET;
    sockname.sin_port   = htons(PUERTO);
    memcpy(&sockname.sin_addr, host->h_addr, host->h_length);

    /* ------------------------------------------------------------------
        3. Se solicita la conexión con el servidor
    -------------------------------------------------------------------*/
    if (connect(sd, (struct sockaddr *) &sockname, sizeof(sockname)) == -1) {
        perror("Error de conexión");
        exit(1);
    }

    mostrarAyuda();

    /* ------------------------------------------------------------------
        4. Conjuntos de select(): vigilamos el teclado (0) y el socket
    -------------------------------------------------------------------*/
    FD_ZERO(&auxfds);
    FD_ZERO(&readfds);
    FD_SET(0, &readfds);
    FD_SET(sd, &readfds);

    /* ------------------------------------------------------------------
        5. Bucle principal
    -------------------------------------------------------------------*/
    do {
        auxfds = readfds;                       /* ¡Copia! select() modifica el conjunto */
        salida = select(sd + 1, &auxfds, NULL, NULL, NULL);

        if (salida <= 0)
            continue;

        /* ---- 5.1 Hay un mensaje del servidor ---- */
        if (FD_ISSET(sd, &auxfds)) {

            if (recibirMensaje(sd, buffer) <= 0) {
                /* recv() = 0: el servidor ha cerrado la conexión */
                printf("Se ha perdido la conexión con el servidor\n");
                fin = 1;
            }
            else {
                printf("%s", buffer);
                fflush(stdout);

                if (strcmp(buffer, "-Err. Demasiados clientes conectados\n") == 0)
                    fin = 1;
                if (strcmp(buffer, "+Ok. Desconexión servidor\n") == 0)
                    fin = 1;
            }
        }

        /* ---- 5.2 El jugador ha escrito algo por teclado ---- */
        if (!fin && FD_ISSET(0, &auxfds)) {

            bzero(buffer, sizeof(buffer));

            if (fgets(buffer, sizeof(buffer), stdin) == NULL)
                strcpy(buffer, "SALIR\n");      /* Ctrl+D: salimos de forma ordenada */

            largo = strlen(buffer);

            /* Si fgets() no ha llegado al '\n', la línea no cabía en el
               buffer: tiramos lo que queda de ella */
            if (largo > 0 && buffer[largo - 1] != '\n') {
                while ((ch = getchar()) != '\n' && ch != EOF)
                    ;
                largo = MAX_TEXTO + 2;
            }

            if (largo - 1 > MAX_TEXTO) {
                printf("El mensaje supera los %d caracteres y no se ha enviado\n", MAX_TEXTO);
                fflush(stdout);
                continue;
            }

            if (enviarMensaje(sd, buffer) == -1) {
                perror("Error al enviar el mensaje");
                fin = 1;
            }

            if (strcmp(buffer, "SALIR\n") == 0)
                fin = 1;
        }

    } while (fin == 0);

    /* ------------------------------------------------------------------
        6. Se cierra el socket
    -------------------------------------------------------------------*/
    close(sd);
    return 0;
}


/*
 * Envía un mensaje en un bloque de tamaño fijo MSG_SIZE (como en los
 * ejemplos del profesor: send(sd, buffer, sizeof(buffer), 0)).
 * send() puede enviar menos bytes de los pedidos, así que repetimos
 * hasta haber enviado el bloque completo.
 */
int enviarMensaje(int sd, const char *texto)
{
    char buffer[MSG_SIZE];
    int enviados = 0, n;

    bzero(buffer, sizeof(buffer));
    strncpy(buffer, texto, MSG_SIZE - 1);

    while (enviados < MSG_SIZE) {
        n = send(sd, buffer + enviados, MSG_SIZE - enviados, 0);
        if (n <= 0)
            return -1;
        enviados += n;
    }
    return enviados;
}

/*
 * Recibe un mensaje completo del servidor (un bloque de MSG_SIZE bytes).
 * TCP es un flujo de bytes: un recv() puede devolver solo una parte del
 * bloque, por eso repetimos hasta completarlo. Aquí sí podemos esperar,
 * porque el servidor siempre envía bloques enteros.
 * Devuelve MSG_SIZE si todo va bien, 0 si el servidor cerró y -1 si error.
 */
int recibirMensaje(int sd, char *buffer)
{
    int recibidos = 0, n;

    bzero(buffer, MSG_SIZE);

    while (recibidos < MSG_SIZE) {
        n = recv(sd, buffer + recibidos, MSG_SIZE - recibidos, 0);
        if (n <= 0)
            return n;
        recibidos += n;
    }
    buffer[MSG_SIZE - 1] = '\0';        /* Por seguridad, siempre terminado en '\0' */
    return recibidos;
}

/* Recordatorio de los mensajes del protocolo */
void mostrarAyuda(void)
{
    printf("=============== DOMINIO TERRITORIAL ===============\n");
    printf("  REGISTRO usuario password\n");
    printf("  USUARIO usuario\n");
    printf("  PASSWORD password\n");
    printf("  INICIAR-PARTIDA\n");
    printf("  ESTADO\n");
    printf("  CONQUISTAR origen destino unidades   (ej: CONQUISTAR B2 B3 10)\n");
    printf("  ATACAR origen destino unidades\n");
    printf("  REFORZAR origen destino unidades\n");
    printf("  PASAR\n");
    printf("  SALIR\n");
    printf("===================================================\n");
    fflush(stdout);
}

