/*
 * =====================================================================
 *  servidor.c  -  REDES Práctica 2: Dominio Territorial
 * ---------------------------------------------------------------------
 *  Servidor TCP concurrente que atiende a varios clientes a la vez
 *  usando select() (un único proceso, sin fork ni hilos).
 *
 *  - Puerto: 2026
 *  - Máximo 10 clientes conectados y 4 partidas simultáneas
 *  - El servidor envía bloques de tamaño fijo (MSG_SIZE), igual que en
 *    los ejemplos del profesor: send(sd, buffer, sizeof(buffer), 0)
 *  - Al recibir, hace UN solo recv() por aviso de select() (así nunca se
 *    queda bloqueado) y va juntando los bytes hasta completar un mensaje
 *  - Respuestas: "+Ok. ..." si todo va bien, "-Err. ..." si hay error
 *
 *  Compilar:  gcc -Wall servidor.c -o servidor
 *  Ejecutar:  ./servidor
 * =====================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>


/* =====================================================================
 *  CONSTANTES
 * ===================================================================== */
#define PUERTO              2026
#define MSG_SIZE            250   /* Tamaño fijo de cada mensaje en el socket   */
#define MAX_TEXTO           200   /* Longitud máxima del texto (enunciado)      */
#define MAX_CLIENTES        10
#define MAX_PARTIDAS        4
#define TAM                 5     /* Tablero de 5 x 5                            */
#define UNIDADES_INICIALES  30
#define MAX_TURNOS          50    /* El enunciado no lo fija: decisión nuestra   */
#define MIN_UNIDADES_ORIGEN 0     /* Unidades que deben quedar en el origen:
                                     0 = se pueden mover todas (enunciado literal)
                                     1 = obliga a dejar siempre una de guarnición */
#define MAX_NOMBRE          50
#define FICHERO_USUARIOS    "usuarios.txt"


/* =====================================================================
 *  TIPOS DE DATOS
 * ===================================================================== */

/* Fase (estado) en la que se encuentra cada cliente dentro del protocolo */
typedef enum { CONECTADO, USUARIO_OK, VALIDADO, ESPERANDO, JUGANDO } Fase;

/* Las tres acciones que mueven unidades comparten casi toda la validación */
typedef enum { CONQUISTAR, ATACAR, REFORZAR } Accion;

typedef struct {
    int  sd;                    /* Socket del cliente (-1 = hueco libre)      */
    Fase fase;                  /* En qué punto del protocolo está            */
    char usuario[MAX_NOMBRE];   /* Nombre de usuario (tras USUARIO)           */
    int  partida;               /* Índice en partidas[] o -1 si no juega      */
    int  numJugador;            /* 1 o 2 dentro de su partida                 */
    char entrada[MSG_SIZE];     /* Bytes recibidos de un mensaje aún incompleto */
    int  nEntrada;              /* Cuántos caracteres hay en entrada[]        */
} Cliente;

typedef struct {
    int propietario;            /* 0 = neutral, 1 = J1, 2 = J2               */
    int unidades;
} Territorio;

typedef struct {
    int activa;                 /* 1 si la partida está en curso              */
    int jugadores[2];           /* Índices en clientes[]: [0]=J1, [1]=J2      */
    Territorio tablero[TAM][TAM];
    int turno;                  /* 1 o 2: jugador al que le toca              */
    int turnosJugados;
} Partida;


/* =====================================================================
 *  VARIABLES GLOBALES
 *  (globales para poder usarlas también desde el manejador de Ctrl+C)
 * ===================================================================== */
int     sdEscucha;                      /* Socket pasivo (listen)          */
fd_set  readfds;                        /* Conjunto "maestro" para select  */
Cliente clientes[MAX_CLIENTES];
int     numClientes = 0;
Partida partidas[MAX_PARTIDAS];
int     esperando = -1;                 /* Cliente en cola (-1 = nadie)    */


/* =====================================================================
 *  PROTOTIPOS
 * ===================================================================== */
/* Comunicación */
int  enviarMensaje(int sd, const char *texto);
void atenderCliente(int idx);

/* Gestión de clientes */
void nuevoCliente(int new_sd, struct sockaddr_in *from);
int  buscarCliente(int sd);
void salirCliente(int idx);
void cerrarServidor(void);
void manejador(int signum);

/* Procesado de mensajes */
void procesarMensaje(int idx, char *buffer);
int  contarPalabras(const char *s);
void cmdUsuario(int idx, char *buffer);
void cmdPassword(int idx, char *buffer);
void cmdRegistro(int idx, char *buffer);
void cmdIniciarPartida(int idx, char *buffer);
void cmdEstado(int idx, char *buffer);
void cmdAccion(int idx, char *buffer, Accion accion);
void cmdPasar(int idx, char *buffer);

/* Usuarios (fichero) */
int  usuarioExiste(const char *nombre);
int  passwordCorrecta(const char *nombre, const char *password);
int  registrarUsuario(const char *nombre, const char *password);
int  usuarioConectado(const char *nombre);

/* Lógica del juego */
int  buscarPartidaLibre(void);
void iniciarPartida(int p, int j1, int j2);
void liberarPartida(int p);
int  rivalDe(int idx);
int  parsearTerritorio(const char *s, int *fila, int *col);
void nombreTerritorio(int fila, int col, char *nombre);
int  adyacentes(int f1, int c1, int f2, int c2);
void enviarTablero(int idx);
void finTurno(int p, const char *textoRival);
void contarJugador(Partida *p, int jugador, int *territorios, int *unidades);
int  partidaTerminada(Partida *p);
void terminarPartida(int p);


/* =====================================================================
 *  MAIN
 * ===================================================================== */
int main(void)
{
    struct sockaddr_in sockname, from;
    socklen_t from_len;
    fd_set auxfds;
    char buffer[MSG_SIZE];
    int new_sd, salida, i, idx, on;

    srand(time(NULL));                          /* Semilla para los territorios aleatorios */

    for (i = 0; i < MAX_CLIENTES; i++)          /* Todos los huecos de clientes libres */
        clientes[i].sd = -1;
    for (i = 0; i < MAX_PARTIDAS; i++)          /* Ninguna partida en curso */
        partidas[i].activa = 0;

    /* ---------------------------------------------------------------
     *  1. Se abre el socket (SOCK_STREAM = TCP)
     * --------------------------------------------------------------- */
    sdEscucha = socket(AF_INET, SOCK_STREAM, 0);
    if (sdEscucha == -1) {
        perror("No se puede abrir el socket servidor");
        exit(1);
    }

    /* Permite reutilizar el puerto nada más cerrar el servidor
       (si no, habría que esperar a que salga del estado TIME_WAIT) */
    on = 1;
    setsockopt(sdEscucha, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));

    /* ---------------------------------------------------------------
     *  2. bind(): se asocia el socket al puerto 2026 en todas las IPs
     * --------------------------------------------------------------- */
    sockname.sin_family      = AF_INET;
    sockname.sin_port        = htons(PUERTO);
    sockname.sin_addr.s_addr = INADDR_ANY;

    if (bind(sdEscucha, (struct sockaddr *) &sockname, sizeof(sockname)) == -1) {
        perror("Error en la operación bind");
        exit(1);
    }

    /* ---------------------------------------------------------------
     *  3. listen(): el socket pasa a ser pasivo (espera conexiones)
     * --------------------------------------------------------------- */
    if (listen(sdEscucha, MAX_CLIENTES) == -1) {
        perror("Error en la operación de listen");
        exit(1);
    }

    /* ---------------------------------------------------------------
     *  4. Se preparan los conjuntos de select()
     *     readfds = conjunto maestro, auxfds = copia que modifica select
     * --------------------------------------------------------------- */
    FD_ZERO(&readfds);
    FD_ZERO(&auxfds);
    FD_SET(sdEscucha, &readfds);   /* Nuevas conexiones          */
    FD_SET(0, &readfds);           /* Teclado del servidor (SALIR) */

    signal(SIGINT, manejador);     /* Ctrl+C cierra el servidor ordenadamente   */
    signal(SIGPIPE, SIG_IGN);      /* Escribir a un cliente caído no nos mata   */

    printf("Servidor Dominio Territorial esperando conexiones en el puerto %d...\n", PUERTO);
    printf("(Escribe SALIR para cerrar el servidor)\n");

    /* ---------------------------------------------------------------
     *  5. Bucle principal: select() nos despierta cuando hay actividad
     * --------------------------------------------------------------- */
    while (1) {

        auxfds = readfds;          /* ¡Copia! select() modifica el conjunto */
        salida = select(FD_SETSIZE, &auxfds, NULL, NULL, NULL);

        if (salida <= 0)
            continue;

        for (i = 0; i < FD_SETSIZE; i++) {

            if (!FD_ISSET(i, &auxfds))
                continue;

            if (i == sdEscucha) {
                /* ---- 5.1 Un cliente nuevo quiere conectarse ---- */
                from_len = sizeof(from);
                new_sd = accept(sdEscucha, (struct sockaddr *) &from, &from_len);
                if (new_sd == -1)
                    perror("Error aceptando peticiones");
                else
                    nuevoCliente(new_sd, &from);
            }
            else if (i == 0) {
                /* ---- 5.2 Se ha escrito algo en el teclado del servidor ---- */
                bzero(buffer, sizeof(buffer));
                if (fgets(buffer, sizeof(buffer), stdin) == NULL)
                    FD_CLR(0, &readfds);            /* Sin teclado: dejamos de vigilarlo */
                else if (strcmp(buffer, "SALIR\n") == 0)
                    cerrarServidor();
            }
            else {
                /* ---- 5.3 Mensaje de un cliente ya conectado ---- */
                idx = buscarCliente(i);
                if (idx != -1)
                    atenderCliente(idx);
            }
        }
    }

    close(sdEscucha);
    return 0;
}


/* =====================================================================
 *  COMUNICACIÓN
 * ===================================================================== */

/*
 * Envía un mensaje de tamaño fijo MSG_SIZE (como el profesor:
 * send(sd, buffer, sizeof(buffer), 0)).
 * send() puede enviar menos bytes de los pedidos, así que repetimos
 * hasta haber enviado el bloque completo.
 */
int enviarMensaje(int sd, const char *texto)
{
    char buffer[MSG_SIZE];
    int enviados = 0, n;

    bzero(buffer, sizeof(buffer));
    strncpy(buffer, texto, MSG_SIZE - 1);

    while (enviados < MSG_SIZE) {
        n = send(sd, buffer + enviados, MSG_SIZE - enviados, 0);
        if (n <= 0)
            return -1;
        enviados += n;
    }
    return enviados;
}

/*
 * select() nos ha avisado de que el cliente idx tiene algo que leer.
 *
 * Hacemos UN solo recv(): como select() garantiza que hay datos (o un
 * cierre), esa llamada no bloquea y el servidor puede seguir atendiendo
 * al resto de clientes.
 *
 * TCP es un flujo de bytes, no de mensajes: un recv() puede traer medio
 * mensaje o varios seguidos. Por eso cada cliente tiene su buffer
 * entrada[], donde vamos guardando caracteres hasta encontrar el final
 * del mensaje: un '\n' (lo añade fgets en el cliente) o un '\0' (el
 * relleno del bloque de tamaño fijo). Los '\0' sueltos son relleno y se
 * ignoran.
 */
void atenderCliente(int idx)
{
    Cliente *c = &clientes[idx];
    char bloque[MSG_SIZE];
    int sd = c->sd;
    int recibidos, k;
    char ch;

    recibidos = recv(sd, bloque, sizeof(bloque), 0);

    if (recibidos <= 0) {
        /* 0 -> el cliente cerró la conexión (p. ej. Ctrl+C); < 0 -> error */
        printf("El cliente <%d> se ha desconectado sin enviar SALIR\n", sd);
        salirCliente(idx);
        return;
    }

    for (k = 0; k < recibidos; k++) {
        ch = bloque[k];

        if (ch == '\r')                           /* telnet manda "\r\n" */
            continue;
        if (ch == '\0' && c->nEntrada == 0)       /* relleno del bloque  */
            continue;

        if (ch == '\n' || ch == '\0') {
            /* ---- Fin de mensaje ---- */
            if (c->nEntrada > MAX_TEXTO) {
                enviarMensaje(sd, "-Err. Mensaje demasiado largo (máximo 200 caracteres)\n");
            }
            else {
                c->entrada[c->nEntrada] = '\0';
                procesarMensaje(idx, c->entrada);
            }

            if (c->sd != sd)                      /* El mensaje era SALIR: ya no existe */
                return;
            c->nEntrada = 0;
        }
        else if (c->nEntrada <= MAX_TEXTO) {
            /* Carácter normal: se guarda. Llegar a MAX_TEXTO + 1 marca
               el mensaje como demasiado largo y el resto se descarta. */
            c->entrada[c->nEntrada] = ch;
            c->nEntrada++;
        }
    }
}


/* =====================================================================
 *  GESTIÓN DE CLIENTES
 * ===================================================================== */

void nuevoCliente(int new_sd, struct sockaddr_in *from)
{
    int i;

    /* Límite de 10 clientes: se avisa y se cierra la conexión */
    if (numClientes >= MAX_CLIENTES) {
        enviarMensaje(new_sd, "-Err. Demasiados clientes conectados\n");
        close(new_sd);
        printf("Conexión rechazada: ya hay %d clientes\n", MAX_CLIENTES);
        return;
    }

    /* Buscamos un hueco libre en el array */
    for (i = 0; i < MAX_CLIENTES; i++)
        if (clientes[i].sd == -1)
            break;

    clientes[i].sd          = new_sd;
    clientes[i].fase        = CONECTADO;
    clientes[i].usuario[0]  = '\0';
    clientes[i].partida     = -1;
    clientes[i].numJugador  = 0;
    clientes[i].nEntrada    = 0;
    numClientes++;

    FD_SET(new_sd, &readfds);   /* A partir de ahora select() vigila este socket */

    enviarMensaje(new_sd, "+Ok. Usuario conectado\n");
    printf("Nuevo cliente <%d> conectado desde %s:%d (%d/%d)\n",
           new_sd, inet_ntoa(from->sin_addr), ntohs(from->sin_port),
           numClientes, MAX_CLIENTES);
}

/* Devuelve la posición en clientes[] del socket sd, o -1 */
int buscarCliente(int sd)
{
    int i;
    for (i = 0; i < MAX_CLIENTES; i++)
        if (clientes[i].sd == sd)
            return i;
    return -1;
}

/*
 * Elimina a un cliente (por SALIR o por desconexión inesperada).
 * Si estaba jugando, avisa al rival y termina la partida.
 * Si estaba esperando, lo saca de la cola.
 */
void salirCliente(int idx)
{
    Cliente *c = &clientes[idx];
    int rival;

    if (c->fase == JUGANDO) {
        rival = rivalDe(idx);
        enviarMensaje(clientes[rival].sd, "+Ok. Tu oponente ha terminado la partida\n");
        liberarPartida(c->partida);
    }
    else if (c->fase == ESPERANDO) {
        esperando = -1;
    }

    printf("Cliente <%d> (%s) desconectado\n",
           c->sd, c->usuario[0] ? c->usuario : "sin identificar");

    close(c->sd);
    FD_CLR(c->sd, &readfds);    /* select() deja de vigilarlo */

    c->sd         = -1;
    c->fase       = CONECTADO;
    c->usuario[0] = '\0';
    c->partida    = -1;
    numClientes--;
}

/* Cierra todas las conexiones avisando a los clientes y termina */
void cerrarServidor(void)
{
    int i;

    for (i = 0; i < MAX_CLIENTES; i++) {
        if (clientes[i].sd != -1) {
            enviarMensaje(clientes[i].sd, "+Ok. Desconexión servidor\n");
            close(clientes[i].sd);
            FD_CLR(clientes[i].sd, &readfds);
        }
    }
    close(sdEscucha);
    printf("Servidor cerrado\n");
    exit(0);
}

/* Manejador de Ctrl+C (SIGINT): cerramos de forma ordenada */
void manejador(int signum)
{
    printf("\nSe ha recibido la señal %d (Ctrl+C)\n", signum);
    cerrarServidor();
}


/* =====================================================================
 *  PROCESADO DE MENSAJES
 * ===================================================================== */

/* Cuenta las palabras separadas por espacios (para validar el formato) */
int contarPalabras(const char *s)
{
    int n = 0, dentro = 0;

    for (; *s; s++) {
        if (isspace((unsigned char) *s))
            dentro = 0;
        else if (!dentro) {
            dentro = 1;
            n++;
        }
    }
    return n;
}

/*
 * Mira la primera palabra del mensaje y llama a la función de ese
 * comando. Cada función comprueba si el comando tiene sentido en la
 * fase en la que está el cliente.
 */
void procesarMensaje(int idx, char *buffer)
{
    char comando[MSG_SIZE];

    printf("<%d> %s: %s\n", clientes[idx].sd,
           clientes[idx].usuario[0] ? clientes[idx].usuario : "?", buffer);

    if (sscanf(buffer, "%s", comando) != 1) {
        enviarMensaje(clientes[idx].sd, "-Err. Mensaje vacío\n");
        return;
    }

    if      (strcmp(comando, "USUARIO") == 0)          cmdUsuario(idx, buffer);
    else if (strcmp(comando, "PASSWORD") == 0)         cmdPassword(idx, buffer);
    else if (strcmp(comando, "REGISTRO") == 0)         cmdRegistro(idx, buffer);
    else if (strcmp(comando, "INICIAR-PARTIDA") == 0)  cmdIniciarPartida(idx, buffer);
    else if (strcmp(comando, "ESTADO") == 0)           cmdEstado(idx, buffer);
    else if (strcmp(comando, "CONQUISTAR") == 0)       cmdAccion(idx, buffer, CONQUISTAR);
    else if (strcmp(comando, "ATACAR") == 0)           cmdAccion(idx, buffer, ATACAR);
    else if (strcmp(comando, "REFORZAR") == 0)         cmdAccion(idx, buffer, REFORZAR);
    else if (strcmp(comando, "PASAR") == 0)            cmdPasar(idx, buffer);
    else if (strcmp(comando, "SALIR") == 0)            salirCliente(idx);
    else
        enviarMensaje(clientes[idx].sd, "-Err. Comando no reconocido\n");
}

/* ---------------------------------------------------------------------
 *  USUARIO usuario
 * --------------------------------------------------------------------- */
void cmdUsuario(int idx, char *buffer)
{
    Cliente *c = &clientes[idx];
    char comando[MSG_SIZE], nombre[MSG_SIZE];

    if (c->fase != CONECTADO && c->fase != USUARIO_OK) {
        enviarMensaje(c->sd, "-Err. Ya estás validado\n");
        return;
    }
    if (contarPalabras(buffer) != 2) {
        enviarMensaje(c->sd, "-Err. Formato incorrecto. Uso: USUARIO usuario\n");
        return;
    }
    sscanf(buffer, "%s %s", comando, nombre);

    if (!usuarioExiste(nombre)) {
        c->fase = CONECTADO;
        c->usuario[0] = '\0';
        enviarMensaje(c->sd, "-Err. Usuario incorrecto\n");
        return;
    }
    if (usuarioConectado(nombre)) {
        enviarMensaje(c->sd, "-Err. Ese usuario ya está conectado\n");
        return;
    }

    strncpy(c->usuario, nombre, MAX_NOMBRE - 1);
    c->usuario[MAX_NOMBRE - 1] = '\0';
    c->fase = USUARIO_OK;
    enviarMensaje(c->sd, "+Ok. Usuario correcto\n");
}

/* ---------------------------------------------------------------------
 *  PASSWORD password
 * --------------------------------------------------------------------- */
void cmdPassword(int idx, char *buffer)
{
    Cliente *c = &clientes[idx];
    char comando[MSG_SIZE], password[MSG_SIZE];

    if (c->fase == CONECTADO) {
        enviarMensaje(c->sd, "-Err. Primero debes indicar el usuario (USUARIO usuario)\n");
        return;
    }
    if (c->fase != USUARIO_OK) {
        enviarMensaje(c->sd, "-Err. Ya estás validado\n");
        return;
    }
    if (contarPalabras(buffer) != 2) {
        enviarMensaje(c->sd, "-Err. Formato incorrecto. Uso: PASSWORD password\n");
        return;
    }
    sscanf(buffer, "%s %s", comando, password);

    /* Por si otro cliente ha entrado con el mismo usuario mientras tanto */
    if (usuarioConectado(c->usuario)) {
        c->fase = CONECTADO;
        enviarMensaje(c->sd, "-Err. Ese usuario ya está conectado\n");
        return;
    }

    if (!passwordCorrecta(c->usuario, password)) {
        enviarMensaje(c->sd, "-Err. Error en la validación\n");
        return;
    }

    c->fase = VALIDADO;
    enviarMensaje(c->sd, "+Ok. Usuario validado\n");
}

/* ---------------------------------------------------------------------
 *  REGISTRO usuario password
 * --------------------------------------------------------------------- */
void cmdRegistro(int idx, char *buffer)
{
    Cliente *c = &clientes[idx];
    char comando[MSG_SIZE], nombre[MSG_SIZE], password[MSG_SIZE];

    if (c->fase != CONECTADO && c->fase != USUARIO_OK) {
        enviarMensaje(c->sd, "-Err. Ya estás validado, no puedes registrar un usuario\n");
        return;
    }
    if (contarPalabras(buffer) != 3) {
        enviarMensaje(c->sd, "-Err. Formato incorrecto. Uso: REGISTRO usuario password\n");
        return;
    }
    sscanf(buffer, "%s %s %s", comando, nombre, password);

    if (strlen(nombre) >= MAX_NOMBRE || strlen(password) >= MAX_NOMBRE) {
        enviarMensaje(c->sd, "-Err. Usuario o password demasiado largos (máximo 49 caracteres)\n");
        return;
    }
    if (usuarioExiste(nombre)) {               /* Control de colisiones de nombres */
        enviarMensaje(c->sd, "-Err. El usuario ya existe\n");
        return;
    }
    if (!registrarUsuario(nombre, password)) {
        enviarMensaje(c->sd, "-Err. No se ha podido guardar el usuario\n");
        return;
    }
    enviarMensaje(c->sd, "+Ok. Usuario registrado correctamente\n");
}

/* ---------------------------------------------------------------------
 *  INICIAR-PARTIDA
 * --------------------------------------------------------------------- */
void cmdIniciarPartida(int idx, char *buffer)
{
    Cliente *c = &clientes[idx];
    int p;

    if (c->fase == CONECTADO || c->fase == USUARIO_OK) {
        enviarMensaje(c->sd, "-Err. Debes validarte antes de iniciar una partida\n");
        return;
    }
    if (c->fase == ESPERANDO) {
        enviarMensaje(c->sd, "-Err. Ya estás esperando a otro jugador\n");
        return;
    }
    if (c->fase == JUGANDO) {
        enviarMensaje(c->sd, "-Err. Ya estás dentro de una partida\n");
        return;
    }
    if (contarPalabras(buffer) != 1) {
        enviarMensaje(c->sd, "-Err. Formato incorrecto. Uso: INICIAR-PARTIDA\n");
        return;
    }

    /* Nadie esperando: este cliente se queda en la cola */
    if (esperando == -1) {
        esperando = idx;
        c->fase = ESPERANDO;
        enviarMensaje(c->sd, "+Ok. Esperando otro jugador\n");
        return;
    }

    /* Ya había alguien: se forma la pareja si queda hueco para otra partida */
    p = buscarPartidaLibre();
    if (p == -1) {
        enviarMensaje(c->sd, "-Err. Se ha alcanzado el máximo de 4 partidas simultáneas, inténtalo más tarde\n");
        return;
    }

    iniciarPartida(p, esperando, idx);   /* El que esperaba es J1 y empieza */
    esperando = -1;
}

/* ---------------------------------------------------------------------
 *  ESTADO
 * --------------------------------------------------------------------- */
void cmdEstado(int idx, char *buffer)
{
    Cliente *c = &clientes[idx];

    if (c->fase != JUGANDO) {
        enviarMensaje(c->sd, "-Err. No estás dentro de una partida\n");
        return;
    }
    if (contarPalabras(buffer) != 1) {
        enviarMensaje(c->sd, "-Err. Formato incorrecto. Uso: ESTADO\n");
        return;
    }
    enviarTablero(idx);
}

/* ---------------------------------------------------------------------
 *  CONQUISTAR / ATACAR / REFORZAR  origen destino unidades
 *  Las tres comparten la mayoría de comprobaciones, por eso van juntas.
 * --------------------------------------------------------------------- */
void cmdAccion(int idx, char *buffer, Accion accion)
{
    const char *nombres[] = { "CONQUISTAR", "ATACAR", "REFORZAR" };
    Cliente *c = &clientes[idx];
    Partida *p;
    Territorio *orig, *dest;
    char comando[MSG_SIZE], sOrig[MSG_SIZE], sDest[MSG_SIZE], sUni[MSG_SIZE];
    char nOrig[3], nDest[3];
    char texto[MSG_SIZE], textoRival[MSG_SIZE];
    char *fin;
    int fo, co, fd, cd, unidades, yo, rival;

    /* 1. El jugador debe estar dentro de una partida */
    if (c->fase != JUGANDO) {
        enviarMensaje(c->sd, "-Err. No estás dentro de una partida\n");
        return;
    }
    p     = &partidas[c->partida];
    yo    = c->numJugador;
    rival = 3 - yo;              /* Si yo soy 1 el rival es 2, y viceversa */

    /* 2. Debe ser su turno */
    if (p->turno != yo) {
        enviarMensaje(c->sd, "-Err. No es tu turno\n");
        return;
    }

    /* 3. Formato: COMANDO origen destino unidades */
    if (contarPalabras(buffer) != 4) {
        snprintf(texto, sizeof(texto),
                 "-Err. Formato incorrecto. Uso: %s origen destino unidades\n", nombres[accion]);
        enviarMensaje(c->sd, texto);
        return;
    }
    sscanf(buffer, "%s %s %s %s", comando, sOrig, sDest, sUni);

    unidades = (int) strtol(sUni, &fin, 10);
    if (fin == sUni || *fin != '\0') {
        enviarMensaje(c->sd, "-Err. El número de unidades debe ser un número entero\n");
        return;
    }

    /* 4. Los territorios existen */
    if (!parsearTerritorio(sOrig, &fo, &co)) {
        enviarMensaje(c->sd, "-Err. El territorio de origen no existe\n");
        return;
    }
    if (!parsearTerritorio(sDest, &fd, &cd)) {
        enviarMensaje(c->sd, "-Err. El territorio de destino no existe\n");
        return;
    }
    orig = &p->tablero[fo][co];
    dest = &p->tablero[fd][cd];
    nombreTerritorio(fo, co, nOrig);
    nombreTerritorio(fd, cd, nDest);

    /* 5. El origen es del jugador */
    if (orig->propietario != yo) {
        enviarMensaje(c->sd, "-Err. El territorio de origen no te pertenece\n");
        return;
    }

    /* 6. Condición sobre el destino, distinta en cada acción */
    if (accion == CONQUISTAR && dest->propietario != 0) {
        enviarMensaje(c->sd, "-Err. El territorio de destino no está sin conquistar\n");
        return;
    }
    if (accion == ATACAR && dest->propietario == yo) {
        enviarMensaje(c->sd, "-Err. No puedes atacar uno de tus propios territorios\n");
        return;
    }
    if (accion == ATACAR && dest->propietario != rival) {
        enviarMensaje(c->sd, "-Err. El territorio de destino no pertenece al jugador contrario\n");
        return;
    }
    if (accion == REFORZAR && dest->propietario != yo) {
        enviarMensaje(c->sd, "-Err. El territorio de destino no te pertenece\n");
        return;
    }

    /* 7. Adyacencia (también descarta origen == destino) */
    if (!adyacentes(fo, co, fd, cd)) {
        enviarMensaje(c->sd, "-Err. Los territorios no son adyacentes\n");
        return;
    }

    /* 8. Unidades suficientes */
    if (unidades <= 0) {
        enviarMensaje(c->sd, "-Err. El número de unidades debe ser mayor que 0\n");
        return;
    }
    if (unidades > orig->unidades - MIN_UNIDADES_ORIGEN) {
        snprintf(texto, sizeof(texto),
                 "-Err. No dispones de suficientes unidades en %s (puedes usar como máximo %d)\n",
                 nOrig, orig->unidades - MIN_UNIDADES_ORIGEN);
        enviarMensaje(c->sd, texto);
        return;
    }

    /* ---- Todo correcto: se aplica la acción ---- */
    orig->unidades -= unidades;           /* Las unidades siempre salen del origen */

    switch (accion) {
    case CONQUISTAR:
        dest->propietario = yo;
        dest->unidades    = unidades;
        snprintf(texto, sizeof(texto), "+Ok. Territorio %s conquistado.\n", nDest);
        snprintf(textoRival, sizeof(textoRival),
                 "+Ok. Tu oponente ha conquistado el territorio neutral %s.\n", nDest);
        break;

    case ATACAR:
        if (unidades > dest->unidades) {
            /* Éxito: el defensor pierde sus unidades y el atacante ocupa el territorio */
            dest->propietario = yo;
            dest->unidades    = unidades;
            snprintf(texto, sizeof(texto), "+Ok. Has conquistado el territorio %s.\n", nDest);
            snprintf(textoRival, sizeof(textoRival),
                     "+Ok. Tu oponente ha atacado %s con %d unidades y lo ha conquistado.\n",
                     nDest, unidades);
        }
        else {
            /* Fracaso (también en empate): el atacante pierde las unidades usadas */
            snprintf(texto, sizeof(texto), "+Ok. Has perdido el ataque contra %s.\n", nDest);
            snprintf(textoRival, sizeof(textoRival),
                     "+Ok. Tu oponente ha atacado %s con %d unidades y has resistido el ataque.\n",
                     nDest, unidades);
        }
        break;

    case REFORZAR:
        dest->unidades += unidades;
        snprintf(texto, sizeof(texto), "+Ok. Territorio reforzado.\n");
        snprintf(textoRival, sizeof(textoRival), "+Ok. Tu oponente ha reforzado sus territorios.\n");
        break;
    }

    enviarMensaje(c->sd, texto);
    printf("Partida %d: J%d %s %s -> %s (%d unidades)\n",
           c->partida, yo, nombres[accion], nOrig, nDest, unidades);

    finTurno(c->partida, textoRival);
}

/* ---------------------------------------------------------------------
 *  PASAR
 * --------------------------------------------------------------------- */
void cmdPasar(int idx, char *buffer)
{
    Cliente *c = &clientes[idx];

    if (c->fase != JUGANDO) {
        enviarMensaje(c->sd, "-Err. No estás dentro de una partida\n");
        return;
    }
    if (partidas[c->partida].turno != c->numJugador) {
        enviarMensaje(c->sd, "-Err. No es tu turno\n");
        return;
    }
    if (contarPalabras(buffer) != 1) {
        enviarMensaje(c->sd, "-Err. Formato incorrecto. Uso: PASAR\n");
        return;
    }

    enviarMensaje(c->sd, "+Ok. Has pasado el turno.\n");
    finTurno(c->partida, "+Ok. Tu oponente ha pasado el turno.\n");
}


/* =====================================================================
 *  USUARIOS (fichero usuarios.txt, una línea "usuario password")
 * ===================================================================== */

int usuarioExiste(const char *nombre)
{
    FILE *f = fopen(FICHERO_USUARIOS, "r");
    char u[MSG_SIZE], p[MSG_SIZE];

    if (f == NULL)                       /* Si no existe el fichero, no hay usuarios */
        return 0;

    while (fscanf(f, "%s %s", u, p) == 2) {
        if (strcmp(u, nombre) == 0) {
            fclose(f);
            return 1;
        }
    }
    fclose(f);
    return 0;
}

int passwordCorrecta(const char *nombre, const char *password)
{
    FILE *f = fopen(FICHERO_USUARIOS, "r");
    char u[MSG_SIZE], p[MSG_SIZE];

    if (f == NULL)
        return 0;

    while (fscanf(f, "%s %s", u, p) == 2) {
        if (strcmp(u, nombre) == 0 && strcmp(p, password) == 0) {
            fclose(f);
            return 1;
        }
    }
    fclose(f);
    return 0;
}

int registrarUsuario(const char *nombre, const char *password)
{
    FILE *f = fopen(FICHERO_USUARIOS, "a");   /* "a" = añadir al final */

    if (f == NULL)
        return 0;

    fprintf(f, "%s %s\n", nombre, password);
    fclose(f);
    return 1;
}

/* ¿Hay otro cliente ya validado con ese nombre? (evita entrar dos veces) */
int usuarioConectado(const char *nombre)
{
    int i;
    for (i = 0; i < MAX_CLIENTES; i++)
        if (clientes[i].sd != -1 && clientes[i].fase >= VALIDADO &&
            strcmp(clientes[i].usuario, nombre) == 0)
            return 1;
    return 0;
}


/* =====================================================================
 *  LÓGICA DEL JUEGO
 * ===================================================================== */

int buscarPartidaLibre(void)
{
    int i;
    for (i = 0; i < MAX_PARTIDAS; i++)
        if (!partidas[i].activa)
            return i;
    return -1;
}

/* Prepara el tablero, coloca a los jugadores y avisa a ambos */
void iniciarPartida(int p, int j1, int j2)
{
    Partida *pa = &partidas[p];
    char texto[MSG_SIZE], n1[3], n2[3];
    int f, c, pos1, pos2;

    pa->activa        = 1;
    pa->jugadores[0]  = j1;
    pa->jugadores[1]  = j2;
    pa->turno         = 1;      /* Empieza J1 (el que estaba esperando) */
    pa->turnosJugados = 0;

    /* Todo el tablero neutral y sin unidades */
    for (f = 0; f < TAM; f++)
        for (c = 0; c < TAM; c++) {
            pa->tablero[f][c].propietario = 0;
            pa->tablero[f][c].unidades    = 0;
        }

    /* Dos casillas aleatorias DISTINTAS (posiciones 0..24) */
    pos1 = rand() % (TAM * TAM);
    do {
        pos2 = rand() % (TAM * TAM);
    } while (pos2 == pos1);

    pa->tablero[pos1 / TAM][pos1 % TAM].propietario = 1;
    pa->tablero[pos1 / TAM][pos1 % TAM].unidades    = UNIDADES_INICIALES;
    pa->tablero[pos2 / TAM][pos2 % TAM].propietario = 2;
    pa->tablero[pos2 / TAM][pos2 % TAM].unidades    = UNIDADES_INICIALES;

    nombreTerritorio(pos1 / TAM, pos1 % TAM, n1);
    nombreTerritorio(pos2 / TAM, pos2 % TAM, n2);

    /* Actualizamos a los dos clientes */
    clientes[j1].fase = JUGANDO;  clientes[j1].partida = p;  clientes[j1].numJugador = 1;
    clientes[j2].fase = JUGANDO;  clientes[j2].partida = p;  clientes[j2].numJugador = 2;

    /* Mensaje exigido por el enunciado */
    enviarMensaje(clientes[j1].sd, "+Ok. Empieza la partida\n");
    enviarMensaje(clientes[j2].sd, "+Ok. Empieza la partida\n");

    /* Información extra para que cada jugador sepa quién es */
    snprintf(texto, sizeof(texto),
             "+Ok. Eres J1 contra %s. Tu territorio inicial es %s con %d unidades. Es tu turno.\n",
             clientes[j2].usuario, n1, UNIDADES_INICIALES);
    enviarMensaje(clientes[j1].sd, texto);

    snprintf(texto, sizeof(texto),
             "+Ok. Eres J2 contra %s. Tu territorio inicial es %s con %d unidades. Empieza tu oponente.\n",
             clientes[j1].usuario, n2, UNIDADES_INICIALES);
    enviarMensaje(clientes[j2].sd, texto);

    printf("Partida %d iniciada: %s (J1 en %s) contra %s (J2 en %s)\n",
           p, clientes[j1].usuario, n1, clientes[j2].usuario, n2);
}

/* Libera la partida y devuelve a sus jugadores a la fase VALIDADO */
void liberarPartida(int p)
{
    int k, j;

    for (k = 0; k < 2; k++) {
        j = partidas[p].jugadores[k];
        clientes[j].fase       = VALIDADO;
        clientes[j].partida    = -1;
        clientes[j].numJugador = 0;
    }
    partidas[p].activa = 0;
    printf("Partida %d finalizada\n", p);
}

/* Índice en clientes[] del rival del cliente idx */
int rivalDe(int idx)
{
    Partida *p = &partidas[clientes[idx].partida];
    return (clientes[idx].numJugador == 1) ? p->jugadores[1] : p->jugadores[0];
}

/* "B3" -> fila 1, columna 2. Devuelve 0 si el territorio no existe */
int parsearTerritorio(const char *s, int *fila, int *col)
{
    char letra;

    if (strlen(s) != 2)
        return 0;

    letra = toupper((unsigned char) s[0]);
    if (letra < 'A' || letra >= 'A' + TAM)
        return 0;
    if (s[1] < '1' || s[1] >= '1' + TAM)
        return 0;

    *fila = letra - 'A';
    *col  = s[1] - '1';
    return 1;
}

/* fila 1, columna 2 -> "B3" */
void nombreTerritorio(int fila, int col, char *nombre)
{
    nombre[0] = 'A' + fila;
    nombre[1] = '1' + col;
    nombre[2] = '\0';
}

/* Adyacentes = arriba, abajo, izquierda o derecha (no diagonal) */
int adyacentes(int f1, int c1, int f2, int c2)
{
    return abs(f1 - f2) + abs(c1 - c2) == 1;
}

/*
 * Envía el tablero al jugador idx. De sus territorios ve las unidades;
 * de los del rival solo ve que son suyos (J1 / J2 sin número).
 * Se manda línea a línea para no superar los 200 caracteres por mensaje.
 */
void enviarTablero(int idx)
{
    Cliente *c = &clientes[idx];
    Partida *p = &partidas[c->partida];
    char linea[MSG_SIZE], celda[16];
    int f, col;

    snprintf(linea, sizeof(linea), "+Ok. Tablero (eres J%d). Turno %d/%d: %s\n",
             c->numJugador, p->turnosJugados + 1, MAX_TURNOS,
             (p->turno == c->numJugador) ? "es tu turno" : "turno del oponente");
    enviarMensaje(c->sd, linea);

    enviarMensaje(c->sd, "    1      2      3      4      5\n");

    for (f = 0; f < TAM; f++) {
        snprintf(linea, sizeof(linea), "%c   ", 'A' + f);

        for (col = 0; col < TAM; col++) {
            Territorio *t = &p->tablero[f][col];

            if (t->propietario == 0)
                strcpy(celda, ".");
            else if (t->propietario == c->numJugador)
                snprintf(celda, sizeof(celda), "J%d(%d)", t->propietario, t->unidades);
            else
                snprintf(celda, sizeof(celda), "J%d", t->propietario);

            snprintf(linea + strlen(linea), sizeof(linea) - strlen(linea), "%-7s", celda);
        }
        strcat(linea, "\n");
        enviarMensaje(c->sd, linea);
    }
}

/*
 * Se llama tras cada acción válida (incluido PASAR):
 * avisa al rival, cuenta el turno, comprueba el final y cambia el turno.
 */
void finTurno(int p, const char *textoRival)
{
    Partida *pa = &partidas[p];
    int actual = pa->turno;
    int rival  = (actual == 1) ? pa->jugadores[1] : pa->jugadores[0];

    enviarMensaje(clientes[rival].sd, textoRival);

    pa->turnosJugados++;

    if (partidaTerminada(pa)) {
        terminarPartida(p);
        return;
    }

    pa->turno = 3 - actual;
    enviarMensaje(clientes[rival].sd, "+Ok. Es tu turno.\n");
}

/* Cuenta los territorios y unidades de un jugador */
void contarJugador(Partida *p, int jugador, int *territorios, int *unidades)
{
    int f, c;

    *territorios = 0;
    *unidades    = 0;
    for (f = 0; f < TAM; f++)
        for (c = 0; c < TAM; c++)
            if (p->tablero[f][c].propietario == jugador) {
                (*territorios)++;
                *unidades += p->tablero[f][c].unidades;
            }
}

/*
 * La partida termina si:
 *  - se alcanza el máximo de turnos,
 *  - un jugador controla los 25 territorios,
 *  - o un jugador se queda sin territorios (ya no podría jugar).
 */
int partidaTerminada(Partida *p)
{
    int t1, u1, t2, u2;

    contarJugador(p, 1, &t1, &u1);
    contarJugador(p, 2, &t2, &u2);

    return p->turnosJugados >= MAX_TURNOS ||
           t1 == TAM * TAM || t2 == TAM * TAM ||
           t1 == 0 || t2 == 0;
}

/* Recuento final: gana quien tenga más territorios; si empatan, más unidades */
void terminarPartida(int p)
{
    Partida *pa = &partidas[p];
    char texto[MSG_SIZE];
    int t1, u1, t2, u2, ganador, k;

    contarJugador(pa, 1, &t1, &u1);
    contarJugador(pa, 2, &t2, &u2);

    if      (t1 > t2) ganador = 1;
    else if (t2 > t1) ganador = 2;
    else if (u1 > u2) ganador = 1;
    else if (u2 > u1) ganador = 2;
    else              ganador = 0;      /* Empate total */

    for (k = 0; k < 2; k++) {
        snprintf(texto, sizeof(texto),
                 "+Ok. Fin de la partida. Territorios: J1=%d, J2=%d. Unidades: J1=%d, J2=%d. %s\n",
                 t1, t2, u1, u2,
                 ganador == 0       ? "Empate."
                 : ganador == k + 1 ? "¡Has ganado!"
                                    : "Has perdido.");
        enviarMensaje(clientes[pa->jugadores[k]].sd, texto);
    }

    printf("Partida %d: J1=%d territorios, J2=%d territorios. Ganador: %s\n",
           p, t1, t2, ganador == 0 ? "empate" : (ganador == 1 ? "J1" : "J2"));

    liberarPartida(p);
}